// js/modules/reservas/reservas.js
import {
  showError,
  showSuccess,
  showLoading,
  clearFeedback,
  setFormLoadingState,
  formatCurrency,
  formatDateTime,
  formatMinutesToHoursMinutes
} from '../../uiUtils.js';
import { turnoService } from '../../services/turnoService.js';
import { registrarEnBitacora } from '../../services/bitacoraservice.js';

// --- MÓDULO DE ESTADO GLOBAL ---
const state = {
  isEditMode: false,
  editingReservaId: null,
  tiemposEstanciaDisponibles: [],
  currentUser: null,
  hotelId: null,
  supabase: null,
  currentBookingTotal: 0,
  configHotel: {
    cobro_al_checkin: true,
    checkin_hora_config: "15:00",
    checkout_hora_config: "12:00",
    impuestos_incluidos_en_precios: false,
    porcentaje_impuesto_principal: 0,
    nombre_impuesto_principal: null,
  }
};

// --- MÓDULO DE UI (VISTA) ---
const ui = {
  container: null, form: null, feedbackDiv: null, formTitle: null,
  submitButton: null, cancelEditButton: null, reservasListEl: null,
  fechaEntradaInput: null, tipoCalculoDuracionEl: null, nochesManualContainer: null,
  cantidadNochesInput: null, tiempoPredefinidoContainer: null, tiempoEstanciaIdSelect: null,
  habitacionIdSelect: null, totalReservaDisplay: null,

  init(containerEl) {
    this.container = containerEl;
    this.form = containerEl.querySelector('#reserva-form');
    this.feedbackDiv = containerEl.querySelector('#reserva-feedback');
    this.formTitle = containerEl.querySelector('#form-title');
    this.submitButton = containerEl.querySelector('#submit-button');
    this.cancelEditButton = containerEl.querySelector('#cancel-edit-button');
    this.reservasListEl = containerEl.querySelector('#reservas-list');
    this.fechaEntradaInput = containerEl.querySelector('#fecha_entrada');
    this.tipoCalculoDuracionEl = containerEl.querySelector('#tipo_calculo_duracion');
    this.nochesManualContainer = containerEl.querySelector('#noches-manual-container');
    this.cantidadNochesInput = containerEl.querySelector('#cantidad_noches');
    this.tiempoPredefinidoContainer = containerEl.querySelector('#tiempo-predefinido-container');
    this.tiempoEstanciaIdSelect = containerEl.querySelector('#tiempo_estancia_id');
    this.habitacionIdSelect = containerEl.querySelector('#habitacion_id');
    this.totalReservaDisplay = containerEl.querySelector('#total-reserva-calculado-display');
  },

  async showConfirmationModal(message, title = "Confirmar Acción") {
    if (typeof Swal !== 'undefined') {
      const result = await Swal.fire({
        title: title, text: message, icon: 'warning', showCancelButton: true,
        confirmButtonColor: '#3085d6', cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, continuar', cancelButtonText: 'No, cancelar'
      });
      return result.isConfirmed;
    }
    return window.confirm(message);
  },

  showInfoModal(message, title = "Información") {
    if (typeof Swal !== 'undefined') Swal.fire(title, message, 'info');
    else alert(`${title}\n\n${message}`);
  },

  updateTotalDisplay() {
    if (!this.totalReservaDisplay) return;
    this.totalReservaDisplay.textContent = formatCurrency(state.currentBookingTotal);
    let impuestoMsg = "";
    if (state.configHotel.porcentaje_impuesto_principal > 0 && state.configHotel.nombre_impuesto_principal) {
        impuestoMsg = state.configHotel.impuestos_incluidos_en_precios 
            ? `(Incluye ${state.configHotel.nombre_impuesto_principal})` 
            : `(+ ${state.configHotel.porcentaje_impuesto_principal}% ${state.configHotel.nombre_impuesto_principal})`;
    }
    this.totalReservaDisplay.innerHTML += ` <small class="text-gray-500 text-xs ml-1">${impuestoMsg}</small>`;
    
    const valorTotalPagoEl = document.getElementById('valor-total-pago');
    if (valorTotalPagoEl) {
        valorTotalPagoEl.textContent = formatCurrency(state.currentBookingTotal);
    }
  }
};

// --- DECLARACIÓN DE FUNCIONES (ANTES DE SU USO EN MOUNT O COMO HANDLERS) ---

// (Aquí van las definiciones completas de:
//  gatherFormData, validateInitialInputs, calculateFechasEstancia, esTiempoEstanciaNoches,
//  calculateMontos, validateAndCalculateBooking, recalcularYActualizarTotalUI,
//  cargarHabitaciones, cargarMetodosPago, cargarTiemposEstancia, loadInitialData,
//  createBooking, updateBooking, prepareEditReserva, handleDeleteReserva, 
//  handleUpdateEstadoReserva, puedeHacerCheckIn, renderReservas, renderReservasGrupo, 
//  mostrarModalAbonoReserva, getAccionesReservaHTML, getBorderColorForEstado, 
//  getBgColorForEstado, getTextColorForEstado, configureFechaEntrada, resetFormToCreateMode
//  ... Y AHORA TAMBIÉN handleFormSubmit y handleListActions)

function gatherFormData() {
  if (!ui.form) return {};
  const formElements = ui.form.elements;
  return {
    cliente_nombre: formElements.cliente_nombre?.value || '',
    telefono: formElements.telefono?.value || '',
    fecha_entrada: formElements.fecha_entrada?.value || '',
    tipo_calculo_duracion: formElements.tipo_calculo_duracion?.value || 'noches_manual',
    cantidad_noches: formElements.cantidad_noches?.value || '1',
    tiempo_estancia_id: formElements.tiempo_estancia_id?.value || '',
    habitacion_id: formElements.habitacion_id?.value || '',
    cantidad_huespedes: formElements.cantidad_huespedes?.value || '1',
    metodo_pago_id: formElements.metodo_pago_id?.value || '',
    monto_abono: formElements.monto_abono?.value || '0',
    notas: formElements.notas?.value || '',
    tipo_pago: formElements.tipo_pago?.value || 'parcial'
  };
}

function validateInitialInputs(formData) {
  if (!formData.cliente_nombre.trim()) throw new Error("El nombre del cliente es obligatorio.");
  if (!formData.habitacion_id) throw new Error("Debe seleccionar una habitación.");
  if (!formData.fecha_entrada) throw new Error("La fecha y hora de llegada son obligatorias.");
  const fechaEntradaDate = new Date(formData.fecha_entrada);
  if (isNaN(fechaEntradaDate.getTime())) throw new Error("La fecha de llegada no es válida.");
  if (!state.isEditMode && fechaEntradaDate < new Date(Date.now() - 10 * 60 * 1000)) {
    throw new Error("La fecha de llegada no puede ser en el pasado para nuevas reservas.");
  }
  if (formData.tipo_calculo_duracion === "noches_manual" && (!formData.cantidad_noches || parseInt(formData.cantidad_noches) < 1)) {
    throw new Error("La cantidad de noches debe ser al menos 1.");
  }
  if (formData.tipo_calculo_duracion === "tiempo_predefinido" && !formData.tiempo_estancia_id) {
    throw new Error("Debe seleccionar un tiempo de estancia predefinido.");
  }
  if (!formData.cantidad_huespedes || parseInt(formData.cantidad_huespedes) < 1) {
    throw new Error("La cantidad de huéspedes debe ser al menos 1.");
  }
  if (!state.isEditMode) { 
    const montoAbonoNum = parseFloat(formData.monto_abono) || 0;
    if (formData.tipo_pago === 'completo' && !formData.metodo_pago_id && state.currentBookingTotal > 0) {
        throw new Error("Si selecciona 'Pago completo' y hay un total a pagar, debe elegir un método de pago.");
    }
    if (formData.tipo_pago === 'parcial' && montoAbonoNum > 0 && !formData.metodo_pago_id) {
        throw new Error("Si registra un abono mayor a cero, debe seleccionar un método de pago.");
    }
  }
}

function calculateFechasEstancia(fechaEntradaStr, tipoCalculo, cantidadNochesStr, tiempoEstanciaId, checkoutHoraConfig) {
  const fechaEntrada = new Date(fechaEntradaStr);
  if (isNaN(fechaEntrada.getTime())) return { errorFechas: "La fecha de entrada no es válida." };
  let fechaSalida, cantidadDuracionOriginal;
  const tipoDuracionOriginal = tipoCalculo;

  if (tipoCalculo === "noches_manual") {
    cantidadDuracionOriginal = parseInt(cantidadNochesStr) || 1;
    if (cantidadDuracionOriginal < 1) return { errorFechas: "Cantidad de noches debe ser al menos 1."};
    fechaSalida = new Date(fechaEntrada);
    fechaSalida.setDate(fechaSalida.getDate() + cantidadDuracionOriginal);
    const [hh, mm] = (checkoutHoraConfig || "12:00").split(':').map(Number);
    fechaSalida.setHours(hh, mm, 0, 0);
  } else { 
    if (!tiempoEstanciaId) return { errorFechas: "No se seleccionó un tiempo de estancia."};
    const tiempo = state.tiemposEstanciaDisponibles.find(ts => ts.id === tiempoEstanciaId);
    if (!tiempo || typeof tiempo.minutos !== 'number' || tiempo.minutos <=0) return { errorFechas: "Tiempo de estancia predefinido inválido." };
    cantidadDuracionOriginal = tiempo.minutos;
    fechaSalida = new Date(fechaEntrada.getTime() + (tiempo.minutos * 60 * 1000));
  }
  if (fechaSalida <= fechaEntrada) return { errorFechas: "La fecha de salida debe ser posterior a la de llegada." };
  return { fechaEntrada, fechaSalida, tipoDuracionOriginal, cantidadDuracionOriginal, errorFechas: null };
}

function esTiempoEstanciaNoches(tiempoEstanciaId) {
  if (!tiempoEstanciaId || !state.tiemposEstanciaDisponibles) return false;
  const tiempo = state.tiemposEstanciaDisponibles.find(ts => ts.id === tiempoEstanciaId);
  return tiempo && tiempo.minutos >= (22 * 60) && tiempo.minutos <= (26 * 60);
}

function calculateMontos(habitacionInfo, huespedes, tipoDuracion, cantDuracion, tiempoId) {
  let montoEstanciaBaseBruto = 0;
  if (!habitacionInfo) return { errorMonto: "Información de habitación no disponible."};

  if (tipoDuracion === "noches_manual") {
    montoEstanciaBaseBruto = (habitacionInfo.precio || 0) * cantDuracion;
  } else { 
    const tiempo = state.tiemposEstanciaDisponibles.find(ts => ts.id === tiempoId);
    if (tiempo && typeof tiempo.precio === 'number' && tiempo.precio >= 0) {
      montoEstanciaBaseBruto = tiempo.precio;
    } else {
      return { errorMonto: "Precio no definido para el tiempo de estancia seleccionado." };
    }
  }

  let montoPorHuespedesAdicionales = 0;
  const capacidadMaxima = habitacionInfo.capacidad_maxima || huespedes;
  if (huespedes > capacidadMaxima) {
    return { errorMonto: `Cantidad de huéspedes (${huespedes}) excede la capacidad máxima (${capacidadMaxima}).` };
  }
  const capacidadBase = habitacionInfo.capacidad_base || 1;
  if (huespedes > capacidadBase) {
    const extraHuespedes = huespedes - capacidadBase;
    let factorDuracionParaAdicional = 1; 
    if (tipoDuracion === "noches_manual") {
      factorDuracionParaAdicional = cantDuracion;
    } else if (tipoDuracion === "tiempo_predefinido" && esTiempoEstanciaNoches(tiempoId)) {
        factorDuracionParaAdicional = Math.max(1, Math.round(cantDuracion / (24 * 60)));
    }
    montoPorHuespedesAdicionales = extraHuespedes * (habitacionInfo.precio_huesped_adicional || 0) * factorDuracionParaAdicional;
  }
  
  const totalAntesDeImpuestos = montoEstanciaBaseBruto + montoPorHuespedesAdicionales;
  let montoImpuestoCalculado = 0;
  let baseImponibleFinal = totalAntesDeImpuestos;

  if (state.configHotel.impuestos_incluidos_en_precios && state.configHotel.porcentaje_impuesto_principal > 0) {
    baseImponibleFinal = totalAntesDeImpuestos / (1 + (state.configHotel.porcentaje_impuesto_principal / 100));
    montoImpuestoCalculado = totalAntesDeImpuestos - baseImponibleFinal;
  } else if (state.configHotel.porcentaje_impuesto_principal > 0) {
    baseImponibleFinal = totalAntesDeImpuestos;
    montoImpuestoCalculado = baseImponibleFinal * (state.configHotel.porcentaje_impuesto_principal / 100);
  }

  return { 
    montoEstanciaBase: Math.round(montoEstanciaBaseBruto), 
    montoPorHuespedesAdicionales: Math.round(montoPorHuespedesAdicionales), 
    montoImpuesto: Math.round(montoImpuestoCalculado),
    baseSinImpuestos: Math.round(baseImponibleFinal), 
    errorMonto: null 
  };
}

async function validateAndCalculateBooking(formData) {
  const [habitacionResult] = await Promise.all([
    state.supabase.from('habitaciones')
      .select('precio, capacidad_base, capacidad_maxima, precio_huesped_adicional')
      .eq('id', formData.habitacion_id).single(),
  ]);

  if (habitacionResult.error) throw new Error(`Error obteniendo detalles de la habitación: ${habitacionResult.error.message}`);
  const habitacionInfo = habitacionResult.data;
  if (!habitacionInfo) throw new Error("No se encontró la habitación seleccionada.");

  const { fechaEntrada, fechaSalida, tipoDuracionOriginal, cantidadDuracionOriginal, errorFechas } = calculateFechasEstancia(
    formData.fecha_entrada, formData.tipo_calculo_duracion, formData.cantidad_noches, formData.tiempo_estancia_id, state.configHotel.checkout_hora_config
  );
  if (errorFechas) throw new Error(errorFechas);
  
  const { data: hayCruce, error: errCruce } = await state.supabase.rpc('validar_cruce_reserva', {
    p_habitacion_id: formData.habitacion_id, p_entrada: fechaEntrada.toISOString(),
    p_salida: fechaSalida.toISOString(), p_reserva_id_excluida: state.isEditMode ? state.editingReservaId : null
  });
  if (errCruce) throw new Error(`Error validando disponibilidad: ${errCruce.message}.`);
  if (hayCruce === true) throw new Error("Conflicto: La habitación no está disponible para el período seleccionado.");

  const { montoEstanciaBase, montoPorHuespedesAdicionales, montoImpuesto, baseSinImpuestos, errorMonto } = calculateMontos(
    habitacionInfo, parseInt(formData.cantidad_huespedes), tipoDuracionOriginal, cantidadDuracionOriginal, formData.tiempo_estancia_id
  );
  if (errorMonto) throw new Error(errorMonto);
  
  state.currentBookingTotal = montoEstanciaBase + montoPorHuespedesAdicionales + montoImpuesto;
  if (ui && typeof ui.updateTotalDisplay === 'function') { ui.updateTotalDisplay(); }

  const datosReserva = {
    cliente_nombre: formData.cliente_nombre.trim(), telefono: formData.telefono.trim() || null,
    cantidad_huespedes: parseInt(formData.cantidad_huespedes), habitacion_id: formData.habitacion_id,
    fecha_inicio: fechaEntrada.toISOString(), fecha_fin: fechaSalida.toISOString(),
    estado: state.isEditMode ? undefined : 'reservada', hotel_id: state.hotelId, usuario_id: state.currentUser.id,
    tipo_duracion: tipoDuracionOriginal, cantidad_duracion: cantidadDuracionOriginal,
    tiempo_estancia_id: tipoDuracionOriginal === 'tiempo_predefinido' ? formData.tiempo_estancia_id : null,
    monto_estancia_base: montoEstanciaBase, 
    monto_por_huespedes_adicionales: montoPorHuespedesAdicionales,
    monto_total: state.currentBookingTotal,
    notas: formData.notas.trim() || null, origen_reserva: 'directa',
    id_temporal_o_final: state.isEditMode ? state.editingReservaId : `TEMP-${Date.now()}` 
  };
  const datosPago = {
    monto_abono: parseFloat(formData.monto_abono) || 0,
    metodo_pago_id: formData.metodo_pago_id || null,
    tipo_pago: formData.tipo_pago 
  };
  const datosImpuestos = {
      monto_estancia_base_sin_impuestos: baseSinImpuestos, 
      monto_impuestos_estancia: montoImpuesto,
      porcentaje_impuestos_aplicado: state.configHotel.porcentaje_impuesto_principal,
      nombre_impuesto_aplicado: state.configHotel.nombre_impuesto_principal
  };
  return { datosReserva, datosPago, datosImpuestos };
}

async function recalcularYActualizarTotalUI() {
    try {
        const formData = gatherFormData();
        if (formData.habitacion_id && formData.fecha_entrada && 
            ((formData.tipo_calculo_duracion === 'noches_manual' && formData.cantidad_noches) || 
             (formData.tipo_calculo_duracion === 'tiempo_predefinido' && formData.tiempo_estancia_id)) &&
            formData.cantidad_huespedes
        ) {
            await validateAndCalculateBooking(formData); 
        } else {
            state.currentBookingTotal = 0; 
            if (ui && typeof ui.updateTotalDisplay === 'function') { ui.updateTotalDisplay(); }
        }
    } catch (calcError) {
        state.currentBookingTotal = 0; 
        if (ui && typeof ui.updateTotalDisplay === 'function') { ui.updateTotalDisplay(); }
        console.warn("[Reservas] Advertencia al recalcular total para UI:", calcError.message);
    }
}

async function cargarHabitaciones() {
  if (!ui.habitacionIdSelect) return;
  ui.habitacionIdSelect.innerHTML = `<option value="">Cargando habitaciones...</option>`;
  ui.habitacionIdSelect.disabled = true;
  const { data: rooms, error } = await state.supabase.from('habitaciones')
    .select('id, nombre, tipo, estado, precio, capacidad_base, capacidad_maxima, precio_huesped_adicional')
    .eq('hotel_id', state.hotelId).eq('activo', true).order('nombre', { ascending: true });
  if (error) { ui.habitacionIdSelect.innerHTML = `<option value="">Error al cargar</option>`; }
  else if (!rooms || rooms.length === 0) { ui.habitacionIdSelect.innerHTML = `<option value="">No hay habitaciones</option>`; }
  else {
    let optionsHtml = `<option value="">Selecciona habitación...</option>`;
    rooms.forEach(room => {
      optionsHtml += `<option value="${room.id}" data-precio="${room.precio || 0}" data-capacidad-base="${room.capacidad_base || 1}" data-capacidad-maxima="${room.capacidad_maxima || room.capacidad_base || 1}" data-precio-extra="${room.precio_huesped_adicional || 0}">${room.nombre} (${formatCurrency(room.precio)})</option>`;
    });
    ui.habitacionIdSelect.innerHTML = optionsHtml;
  }
  ui.habitacionIdSelect.disabled = false;
}

async function cargarMetodosPago() {
  if (!ui.form || !ui.form.elements.metodo_pago_id) return;
  const select = ui.form.elements.metodo_pago_id;
  select.innerHTML = `<option value="">Cargando métodos...</option>`;
  const { data, error } = await state.supabase.from('metodos_pago').select('id, nombre')
    .eq('hotel_id', state.hotelId).eq('activo', true).order('nombre');
  if (error) { select.innerHTML = `<option value="">Error</option>`; return; }
  let optionsHtml = `<option value="">Selecciona método de pago...</option>`; 
  if (data && data.length > 0) { data.forEach(pago => optionsHtml += `<option value="${pago.id}">${pago.nombre}</option>`); }
  else { optionsHtml = `<option value="">No hay métodos de pago</option>`; }
  select.innerHTML = optionsHtml;
}

async function cargarTiemposEstancia() {
  if (!ui.tiempoEstanciaIdSelect) return;
  const { data, error } = await state.supabase
    .from('tiempos_estancia')
    .select('id, nombre, minutos, precio')
    .eq('hotel_id', state.hotelId)
    .eq('activo', true)
    .order('minutos', { ascending: true });
  ui.tiempoEstanciaIdSelect.innerHTML = ""; 
  if (error || !data || !data.length) {
    const opt = document.createElement('option'); opt.value = "";
    opt.textContent = error ? "Error cargando tiempos" : "No hay tiempos predefinidos";
    ui.tiempoEstanciaIdSelect.appendChild(opt);
    state.tiemposEstanciaDisponibles = []; return;
  }
  state.tiemposEstanciaDisponibles = data;
  const placeholder = document.createElement('option');
  placeholder.value = ""; placeholder.textContent = "Selecciona un tiempo...";
  ui.tiempoEstanciaIdSelect.appendChild(placeholder);
  data.forEach(ts => {
    const option = document.createElement('option'); option.value = ts.id;
    const horasAprox = formatMinutesToHoursMinutes(ts.minutos);
    option.textContent = `${ts.nombre} (${formatCurrency(ts.precio)}) - ${horasAprox}`;
    option.setAttribute('data-precio', ts.precio); 
    ui.tiempoEstanciaIdSelect.appendChild(option);
  });
}

async function loadInitialData() {
  if (!ui.habitacionIdSelect || !ui.form?.elements.metodo_pago_id || !ui.tiempoEstanciaIdSelect) {
      console.error("[Reservas] Elementos de UI para carga inicial no encontrados.");
      return;
  }
  try {
    const { data: config, error: configError } = await state.supabase
        .from('configuracion_hotel')
        .select('cobro_al_checkin, checkin_hora_config, checkout_hora_config, impuestos_incluidos_en_precios, porcentaje_impuesto_principal, nombre_impuesto_principal')
        .eq('hotel_id', state.hotelId)
        .single();
    if (configError && configError.code !== 'PGRST116') throw configError;
    if (config) {
        state.configHotel.cobro_al_checkin = config.cobro_al_checkin === true;
        state.configHotel.checkin_hora_config = config.checkin_hora_config || "15:00";
        state.configHotel.checkout_hora_config = config.checkout_hora_config || "12:00";
        state.configHotel.impuestos_incluidos_en_precios = config.impuestos_incluidos_en_precios === true;
        state.configHotel.porcentaje_impuesto_principal = parseFloat(config.porcentaje_impuesto_principal) || 0;
        state.configHotel.nombre_impuesto_principal = config.nombre_impuesto_principal || null;
    } else {
        console.warn(`[Reservas] No se encontró configuración para el hotel ${state.hotelId}. Usando valores predeterminados.`);
    }
  } catch (err) {
      console.error("[Reservas] Error cargando configuración del hotel:", err);
      if(ui.feedbackDiv) showError(ui.feedbackDiv, "Error crítico: No se pudo cargar la configuración del hotel.");
  }
  await Promise.all([cargarHabitaciones(), cargarMetodosPago(), cargarTiemposEstancia()]);
  await renderReservas();
}

async function createBooking(payload) {
  const { datosReserva, datosPago, datosImpuestos } = payload;
  const reservaParaInsertar = {
      ...datosReserva,
      monto_estancia_base_sin_impuestos: datosImpuestos.monto_estancia_base_sin_impuestos,
      monto_impuestos_estancia: datosImpuestos.montoImpuesto,
      porcentaje_impuestos_aplicado: datosImpuestos.porcentajeAplicado,
      nombre_impuesto_aplicado: datosImpuestos.nombreImpuesto,
  };
  delete reservaParaInsertar.id_temporal_o_final;

  const { data: reservaInsertada, error: errInsert } = await state.supabase
    .from('reservas').insert(reservaParaInsertar).select().single();
  if (errInsert) throw new Error(`Error al guardar reserva: ${errInsert.message}`);
  const nuevaReservaId = reservaInsertada.id;
  const tipoPago = datosPago?.tipo_pago || 'parcial';
  const montoPagado = tipoPago === "completo" ? state.currentBookingTotal : (parseFloat(datosPago?.monto_abono) || 0);
  if (montoPagado > 0) {
    const turnoId = turnoService.getActiveTurnId();
    if (!turnoId && ui.feedbackDiv) showError(ui.feedbackDiv, "Advertencia: Reserva creada, pero pago no en caja (no hay turno).");
    else if (turnoId) {
      const movCaja = {
        hotel_id: state.hotelId, tipo: 'ingreso', monto: montoPagado,
        concepto: `${tipoPago === "completo" ? 'Pago completo Reserva' : 'Abono Reserva'} ${reservaInsertada.cliente_nombre} (#${nuevaReservaId.substring(0,8)})`,
        referencia: nuevaReservaId, metodo_pago_id: datosPago.metodo_pago_id, usuario_id: state.currentUser.id, turno_id: turnoId 
      };
      const { error: errCaja } = await state.supabase.from('caja').insert(movCaja);
      if (errCaja && ui.feedbackDiv) showError(ui.feedbackDiv, `Advertencia: Reserva creada. Error en caja: ${errCaja.message}`);
    }
  }
  if (datosPago.metodo_pago_id && montoPagado > 0) {
    await state.supabase.from('pagos_reserva').insert({
      reserva_id: nuevaReservaId, monto: montoPagado, metodo_pago_id: datosPago.metodo_pago_id,
      fecha_pago: new Date().toISOString(), hotel_id: state.hotelId, usuario_id: state.currentUser.id
    });
  } else if (montoPagado > 0 && !datosPago.metodo_pago_id && ui.feedbackDiv) {
      showError(ui.feedbackDiv, "Advertencia: Pago indicado sin método.");
  }
  await state.supabase.from('habitaciones').update({ estado: "reservada" }).eq('id', reservaInsertada.habitacion_id).eq('estado', 'libre');
  return reservaInsertada;
}

async function updateBooking(payload) {
  const { datosReserva, datosImpuestos } = payload;
  delete datosReserva.hotel_id; delete datosReserva.estado; delete datosReserva.usuario_id; delete datosReserva.id_temporal_o_final;
  const reservaUpd = { 
    ...datosReserva, 
    monto_estancia_base_sin_impuestos: datosImpuestos.monto_estancia_base_sin_impuestos,
    monto_impuestos_estancia: datosImpuestos.montoImpuesto,
    porcentaje_impuestos_aplicado: datosImpuestos.porcentajeAplicado,
    nombre_impuesto_aplicado: datosImpuestos.nombreImpuesto,
    monto_total: state.currentBookingTotal 
  };
  const { error } = await state.supabase.from('reservas').update(reservaUpd).eq('id', state.editingReservaId);
  if (error) throw new Error(`Error actualizando reserva: ${error.message}`);
}

async function prepareEditReserva(reservaId) {
  if (ui.feedbackDiv) clearFeedback(ui.feedbackDiv);
  showLoading(ui.feedbackDiv, "Cargando datos para editar...");
  const { data: r, error } = await state.supabase.from('reservas').select('*').eq('id', reservaId).single();
  clearFeedback(ui.feedbackDiv);
  if (error || !r) throw new Error("No se pudo cargar la reserva para editar.");
  ui.form.elements.cliente_nombre.value = r.cliente_nombre || '';
  ui.form.elements.telefono.value = r.telefono || '';
  ui.form.elements.cantidad_huespedes.value = r.cantidad_huespedes || 1;
  ui.form.elements.habitacion_id.value = r.habitacion_id;
  if (r.fecha_inicio) {
    const fEntrada = new Date(r.fecha_inicio);
    ui.form.elements.fecha_entrada.value = new Date(fEntrada.getTime() - (fEntrada.getTimezoneOffset()*60000)).toISOString().slice(0,16);
  } else { ui.form.elements.fecha_entrada.value = ''; }
  if (r.tiempo_estancia_id && r.tipo_duracion === 'tiempo_estancia') {
    ui.tipoCalculoDuracionEl.value = 'tiempo_predefinido';
    ui.form.elements.tiempo_estancia_id.value = r.tiempo_estancia_id;
  } else {
    ui.tipoCalculoDuracionEl.value = 'noches_manual';
    ui.form.elements.cantidad_noches.value = r.cantidad_duracion || 1;
  }
  if (ui.tipoCalculoDuracionEl) ui.tipoCalculoDuracionEl.dispatchEvent(new Event('change'));
  ui.form.elements.tipo_pago.value = 'parcial'; ui.form.elements.tipo_pago.disabled = true;
  ui.form.elements.metodo_pago_id.value = ''; ui.form.elements.metodo_pago_id.disabled = true;
  document.getElementById('abono-container').style.display = 'none';
  document.getElementById('total-pago-completo').style.display = 'none';
  ui.form.elements.notas.value = r.notas || '';
  ui.formTitle.textContent = `Editar Reserva (ID: ${reservaId.substring(0,8)})`;
  ui.submitButton.textContent = "Actualizar Reserva";
  if (ui.cancelEditButton) ui.cancelEditButton.style.display = 'inline-flex';
  if (ui.form) ui.form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  state.isEditMode = true; state.editingReservaId = reservaId;
  await recalcularYActualizarTotalUI();
}

async function handleDeleteReserva(reservaId) {
  const r = (await state.supabase.from('reservas').select('cliente_nombre').eq('id', reservaId).single()).data;
  const conf = await ui.showConfirmationModal(`¿Eliminar reserva de ${r?.cliente_nombre || 'cliente'} y sus pagos?`);
  if (!conf) return;
  showLoading(ui.feedbackDiv, "Eliminando...");
  await state.supabase.from('pagos_reserva').delete().eq('reserva_id', reservaId);
  const { error } = await state.supabase.from('reservas').delete().eq('id', reservaId);
  clearFeedback(ui.feedbackDiv);
  if (error) throw new Error(`Error al eliminar reserva: ${error.message}`);
  showSuccess(ui.feedbackDiv, "Reserva eliminada.");
  await registrarEnBitacora({ supabase: state.supabase, hotel_id: state.hotelId, usuario_id: state.currentUser.id, modulo: 'Reservas', accion: 'ELIMINAR_RESERVA', detalles: { reserva_id: reservaId, cliente: r?.cliente_nombre } });
  await renderReservas();
  document.dispatchEvent(new CustomEvent('datosActualizados'));
}

async function handleUpdateEstadoReserva(reservaId, nuevoEstadoReserva, nuevoEstadoHabitacion, habitacionIdReserva, forzarDisponibleHabitacion = false) {
  if (!ui.feedbackDiv) return;
  showLoading(ui.feedbackDiv, `Actualizando a ${nuevoEstadoReserva}...`);
  const updatesReserva = { estado: nuevoEstadoReserva };
  if (nuevoEstadoReserva === 'activa' && !forzarDisponibleHabitacion) updatesReserva.fecha_inicio = new Date().toISOString();
  const { error: errRes } = await state.supabase.from('reservas').update(updatesReserva).eq('id', reservaId);
  if (errRes) throw new Error(`Error actualizando reserva: ${errRes.message}`);
  let msgExito = `Reserva actualizada a ${nuevoEstadoReserva}!`;
  let habActualizada = false;
  if (habitacionIdReserva && nuevoEstadoHabitacion) {
    const { error: errHab } = await state.supabase.from('habitaciones').update({ estado: nuevoEstadoHabitacion }).eq('id', habitacionIdReserva);
    if (errHab) msgExito += ` (Error hab: ${errHab.message})`; else habActualizada = true;
  }
  showSuccess(ui.feedbackDiv, msgExito);
  await registrarEnBitacora({ supabase: state.supabase, hotel_id: state.hotelId, usuario_id: state.currentUser.id, modulo: 'Reservas', accion: `CAMBIO_ESTADO_RESERVA_${nuevoEstadoReserva.toUpperCase()}`, detalles: { reserva_id: reservaId, nuevo_estado: nuevoEstadoReserva, habitacion_id: habitacionIdReserva, nuevo_estado_hab: nuevoEstadoHabitacion } });
  await renderReservas();
  if (habActualizada) document.dispatchEvent(new CustomEvent('datosActualizados'));
}

async function puedeHacerCheckIn(reservaId) {
    const { data: r, error: errR } = await state.supabase.from('reservas').select('monto_total, id').eq('id', reservaId).single();
    if (errR || !r) return false;
    const { data: p, error: errP } = await state.supabase.from('pagos_reserva').select('monto').eq('reserva_id', reservaId);
    if (errP) return false;
    const totalPagado = p ? p.reduce((s, i) => s + Number(i.monto), 0) : 0;
    if (!r.monto_total || r.monto_total <= 0) return true;
    return totalPagado >= r.monto_total;
}

async function renderReservas() {
  if (!ui.reservasListEl) return;
  showLoading(ui.reservasListEl, "Cargando reservas...");
  const { data: rs, error } = await state.supabase.from('reservas')
    .select(`*, habitaciones(nombre, tipo), pagos_reserva(monto)`)
    .eq('hotel_id', state.hotelId).in('estado', ['reservada', 'confirmada', 'activa'])
    .order('fecha_inicio', { ascending: true }).limit(100);
  clearFeedback(ui.reservasListEl);
  if (error) { showError(ui.reservasListEl, `Error cargando reservas: ${error.message}`); return; }
  if (!rs || rs.length === 0) { ui.reservasListEl.innerHTML = `<div class="info-box p-4 text-center text-gray-500">No hay reservas activas o próximas.</div>`; return; }
  rs.forEach(r => {
    const abonado = r.pagos_reserva ? r.pagos_reserva.reduce((s, p) => s + Number(p.monto), 0) : 0;
    r.abonado = abonado; r.pendiente = Math.max((r.monto_total || 0) - abonado, 0);
  });
  const grouped = rs.reduce((acc, r) => { (acc[r.estado] = acc[r.estado] || []).push(r); return acc; }, {});
  let html = '';
  ['reservada', 'confirmada', 'activa'].forEach(k => { if (grouped[k]?.length) html += renderReservasGrupo(k.charAt(0).toUpperCase() + k.slice(1).replace(/_/g, ' '), grouped[k]); });
  ui.reservasListEl.innerHTML = html || `<div class="info-box p-4 text-center text-gray-500">No hay reservas.</div>`;
}

function renderReservasGrupo(titulo, grupo) {
  let html = `<h3 class="text-xl font-bold mt-6 mb-3 text-blue-700 border-b pb-2">${titulo} (${grupo.length})</h3>`;
  html += `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">`;
  grupo.forEach(r => {
    const estadoActual = (r.estado || 'N/A').toUpperCase().replace(/_/g, ' ');
    html += `<div class="p-4 bg-white rounded-lg shadow-md border-l-4 ${getBorderColorForEstado(r.estado)}"><div class="flex justify-between items-start mb-2"><h4 class="font-semibold text-lg text-gray-800">${r.cliente_nombre}</h4><span class="text-xs font-semibold px-2.5 py-0.5 rounded-full ${getBgColorForEstado(r.estado)} ${getTextColorForEstado(r.estado)}">${estadoActual}</span></div><div class="text-sm space-y-1 text-gray-600"><p><strong>Hab:</strong> ${r.habitaciones?.nombre||'N/A'}</p><p><strong>Huésp:</strong> ${r.cantidad_huespedes}</p><p><strong>Llega:</strong> ${formatDateTime(r.fecha_inicio)}</p><p><strong>Sale:</strong> ${formatDateTime(r.fecha_fin)}</p><p><strong>Total:</strong> ${formatCurrency(r.monto_total)}</p>${r.abonado>0?`<p style="color:#059669"><strong>Abonado:</strong> ${formatCurrency(r.abonado)}</p>`:''}${r.pendiente>0?`<p style="color:#b91c1c"><strong>Pendiente:</strong> ${formatCurrency(r.pendiente)}</p>`:''}${r.notas?`<p class="mt-1"><strong>Notas:</strong> <span class="italic">${r.notas}</span></p>`:''}</div><div class="mt-4 pt-3 border-t flex flex-wrap gap-2">${getAccionesReservaHTML(r)}</div></div>`;
  });
  html += `</div>`; return html;
}

async function mostrarModalAbonoReserva(reservaActual) {
  const { data: mP, error: errMP } = await state.supabase.from('metodos_pago').select('id, nombre').eq('hotel_id', state.hotelId).eq('activo', true).order('nombre');
  if (errMP || !mP?.length) { Swal.fire('Error', 'No hay métodos de pago activos.', 'error'); return; }
  const selOpts = mP.map(mp => `<option value="${mp.id}">${mp.nombre}</option>`).join('');
  const { data: pExist } = await state.supabase.from('pagos_reserva').select('monto').eq('reserva_id', reservaActual.id);
  const totAbonado = pExist ? pExist.reduce((s, p) => s + Number(p.monto), 0) : 0;
  const mPend = Math.max(0, (reservaActual.monto_total || 0) - totAbonado);
  if (mPend === 0 && reservaActual.monto_total > 0) { Swal.fire('Info', 'Reserva pagada.', 'info'); return; }
  const { value: fVal, isConfirmed } = await Swal.fire({
    title: `Abono para ${reservaActual.cliente_nombre}`,
    html: `<p class="mb-2 text-sm">Pendiente: <strong class="text-red-600">${formatCurrency(mPend)}</strong></p><input id="swal-abono-monto" class="swal2-input" type="number" min="1" ${mPend>0?`max="${mPend}"`:''} placeholder="Valor (máx. ${formatCurrency(mPend)})" value="${mPend>0?mPend:''}"><select id="swal-metodo-pago" class="swal2-input"><option value="">Método...</option>${selOpts}</select>`,
    focusConfirm: false,
    preConfirm: () => {
      const m = parseFloat(document.getElementById('swal-abono-monto').value) || 0;
      const met = document.getElementById('swal-metodo-pago').value;
      if (m<=0) { Swal.showValidationMessage('Monto > 0.'); return false; }
      if (mPend>0 && m>mPend) { Swal.showValidationMessage(`No exceder pendiente de ${formatCurrency(mPend)}.`); return false; }
      if (!met) { Swal.showValidationMessage('Seleccione método.'); return false; }
      return { monto:m, metodo:met };
    },
    confirmButtonText: 'Registrar Abono', showCancelButton: true, cancelButtonText: 'Cancelar'
  });
  if (!isConfirmed || !fVal) return;
  const { error: errAbono } = await state.supabase.from('pagos_reserva').insert({
    reserva_id:reservaActual.id, monto:fVal.monto, metodo_pago_id:fVal.metodo,
    fecha_pago:new Date().toISOString(), hotel_id:state.hotelId, usuario_id:state.currentUser.id
  });
  if (errAbono) { Swal.fire('Error', `No se pudo registrar abono: ${errAbono.message}`, 'error'); return; }
  const turnoId = turnoService.getActiveTurnId(); let movCajaOK = false;
  if (!turnoId) Swal.fire('Advertencia', 'Abono en reserva, pero NO en caja (no hay turno).', 'warning');
  else {
    const movCaja = { hotel_id:state.hotelId, tipo:'ingreso', monto:fVal.monto, concepto:`Abono reserva #${reservaActual.id.substring(0,8)} (${reservaActual.cliente_nombre})`, referencia:reservaActual.id, metodo_pago_id:fVal.metodo, usuario_id:state.currentUser.id, turno_id:turnoId };
    const { error: errCaja } = await state.supabase.from('caja').insert(movCaja);
    if (errCaja) Swal.fire('Advertencia', `Abono en reserva, error en caja: ${errCaja.message}`, 'warning');
    else movCajaOK = true;
  }
  if (movCajaOK) Swal.fire('¡Éxito!', 'Abono registrado en reserva y caja.', 'success');
  await registrarEnBitacora({ supabase: state.supabase, hotel_id: state.hotelId, usuario_id: state.currentUser.id, modulo: 'Reservas', accion: 'REGISTRAR_ABONO', detalles: { reserva_id: reservaActual.id, monto: fVal.monto, metodo_pago: fVal.metodo } });
  await renderReservas();
}

function getAccionesReservaHTML(reserva) {
  let actions = ''; const baseClass = "button text-xs px-2.5 py-1 rounded-md shadow-sm disabled:opacity-50"; const estado = reserva.estado;
  if (['reservada','confirmada','activa'].includes(estado) && reserva.pendiente > 0) actions += `<button class="${baseClass} bg-green-500 hover:bg-green-600 text-white" data-action="abonar" data-id="${reserva.id}">Abonar</button>`;
  if (['reservada','confirmada'].includes(estado)) actions += `<button class="${baseClass} bg-yellow-400 hover:bg-yellow-500 text-black" data-action="editar" data-id="${reserva.id}">Editar</button>`;
  if (['reservada','confirmada','activa'].includes(estado)) actions += `<button class="${baseClass} bg-red-500 hover:bg-red-600 text-white" data-action="cancelar" data-id="${reserva.id}" data-habitacion-id="${reserva.habitacion_id}">Cancelar</button>`;
  if (estado === 'reservada') actions += `<button class="${baseClass} bg-cyan-500 hover:bg-cyan-600 text-white" data-action="confirmar" data-id="${reserva.id}" data-habitacion-id="${reserva.habitacion_id}">Confirmar</button>`;
  if (estado === 'confirmada') {
      const fInicio = new Date(reserva.fecha_inicio); const ahora = new Date();
      const inicioVCheckin = new Date(fInicio.getTime() - 24*60*60*1000); const finDCheckin = new Date(fInicio.getFullYear(),fInicio.getMonth(),fInicio.getDate(),23,59,59);
      if (ahora >= inicioVCheckin && ahora <= finDCheckin) actions += `<button class="${baseClass} bg-blue-500 hover:bg-blue-600 text-white" data-action="checkin" data-id="${reserva.id}" data-habitacion-id="${reserva.habitacion_id}">Check-in</button>`;
  }
  if (estado === 'activa') actions += `<button class="${baseClass} bg-teal-500 hover:bg-teal-600 text-white" data-action="checkout" data-id="${reserva.id}" data-habitacion-id="${reserva.habitacion_id}">Check-out</button>`;
  return actions;
}

function configureFechaEntrada(fechaEntradaInput) {
  if(!fechaEntradaInput) return;
  const now = new Date();
  const todayForMin = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const year = todayForMin.getFullYear();
  const month = (todayForMin.getMonth() + 1).toString().padStart(2, '0');
  const day = todayForMin.getDate().toString().padStart(2, '0');
  fechaEntradaInput.min = `${year}-${month}-${day}T00:00`;
}

function resetFormToCreateMode() {
  if (ui.form) {
    ui.form.reset();
    if (ui.tipoCalculoDuracionEl) {
        ui.tipoCalculoDuracionEl.value = 'noches_manual';
        ui.tipoCalculoDuracionEl.dispatchEvent(new Event('change'));
    }
    if (ui.fechaEntradaInput) configureFechaEntrada(ui.fechaEntradaInput); 
    if (ui.form.elements.tipo_pago) {
        ui.form.elements.tipo_pago.disabled = false;
        ui.form.elements.tipo_pago.value = 'parcial'; 
        ui.form.elements.tipo_pago.dispatchEvent(new Event('change'));
    }
    if (ui.form.elements.metodo_pago_id) ui.form.elements.metodo_pago_id.disabled = false;
    if (ui.form.elements.monto_abono) ui.form.elements.monto_abono.value = '';
  }
  if (ui.formTitle) ui.formTitle.textContent = "Registrar Nueva Reserva";
  if (ui.submitButton) ui.submitButton.textContent = "Registrar Reserva";
  if (ui.cancelEditButton) ui.cancelEditButton.style.display = 'none';
  state.isEditMode = false; state.editingReservaId = null; state.currentBookingTotal = 0;
  ui.updateTotalDisplay();
}

function getBorderColorForEstado(e) { const c={'reservada':'border-yellow-400','confirmada':'border-green-500','activa':'border-blue-500','cancelada':'border-red-500','no_show':'border-purple-500','completada':'border-gray-400'}; return c[e]||'border-gray-300'; }
function getBgColorForEstado(e) { const c={'reservada':'bg-yellow-100','confirmada':'bg-green-100','activa':'bg-blue-100','cancelada':'bg-red-100','no_show':'bg-purple-100','completada':'bg-gray-100'}; return c[e]||'bg-gray-200'; }
function getTextColorForEstado(e) { const c={'reservada':'text-yellow-800','confirmada':'text-green-800','activa':'text-blue-800','cancelada':'text-red-800','no_show':'text-purple-800','completada':'text-gray-700'}; return c[e]||'text-gray-700'; }

// --- FIN DE FUNCIONES AUXILIARES Y CRUD ---

// --- PUNTO DE ENTRADA DEL MÓDULO ---
export async function mount(container, supabaseClient, user, hotelId) {
  state.supabase = supabaseClient;
  state.currentUser = user;
  state.hotelId = hotelId;

  if (!user || !user.id) { container.innerHTML = `<p class="error-box">Usuario no autenticado.</p>`; return; }
  if (!hotelId) { container.innerHTML = `<p class="error-box">ID del hotel no disponible.</p>`; return; }

  container.innerHTML = `
    <div class="max-w-4xl mx-auto mt-7 px-4">
      <h2 id="form-title" class="text-2xl md:text-3xl font-bold mb-6 text-blue-800">Registrar Nueva Reserva</h2>
      <form id="reserva-form" class="space-y-5 bg-slate-50 rounded-xl p-6 border border-slate-200 mb-8 shadow-md">
        <fieldset class="border border-slate-300 p-4 rounded-md">
          <legend class="text-lg font-semibold text-slate-700 px-2">Datos del Cliente</legend>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
            <div><label for="cliente_nombre" class="form-label">Nombre completo*</label><input name="cliente_nombre" id="cliente_nombre" class="form-control" required maxlength="120" /></div>
            <div><label for="telefono" class="form-label">Teléfono</label><input name="telefono" id="telefono" type="tel" class="form-control" maxlength="30" /></div>
          </div>
        </fieldset>
        <fieldset class="border border-slate-300 p-4 rounded-md">
          <legend class="text-lg font-semibold text-slate-700 px-2">Detalles de la Reserva</legend>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-5 mt-2">
            <div><label for="fecha_entrada" class="form-label">Fecha y hora de llegada*</label><input type="datetime-local" name="fecha_entrada" id="fecha_entrada" class="form-control" required /></div>
            <div><label for="tipo_calculo_duracion" class="form-label">Calcular duración por*</label><select name="tipo_calculo_duracion" id="tipo_calculo_duracion" class="form-control" required><option value="noches_manual">Noches (manual)</option><option value="tiempo_predefinido">Tiempo predefinido</option></select></div>
            <div id="noches-manual-container"><label for="cantidad_noches" class="form-label">Cantidad de noches*</label><input name="cantidad_noches" id="cantidad_noches" type="number" min="1" max="90" value="1" class="form-control" /></div>
            <div id="tiempo-predefinido-container" style="display:none;"><label for="tiempo_estancia_id" class="form-label">Selecciona tiempo de estancia*</label><select name="tiempo_estancia_id" id="tiempo_estancia_id" class="form-control"></select></div>
            <div><label for="habitacion_id" class="form-label">Habitación*</label><select name="habitacion_id" id="habitacion_id" class="form-control" required></select></div>
            <div><label for="cantidad_huespedes" class="form-label">Cantidad de huéspedes*</label><input name="cantidad_huespedes" id="cantidad_huespedes" type="number" min="1" max="20" value="1" class="form-control" required /></div>
          </div>
        </fieldset>
        
        <div class="p-4 bg-blue-50 border border-blue-200 rounded-md text-center">
            <p class="text-sm text-blue-700">Total Estimado de la Reserva:</p>
            <p id="total-reserva-calculado-display" class="text-2xl font-bold text-blue-600">${formatCurrency(0)}</p>
        </div>

        <fieldset class="border border-slate-300 p-4 rounded-md">
          <legend class="text-lg font-semibold text-slate-700 px-2">Pago y Adicionales</legend>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-5 mt-2">
            <div><label for="tipo_pago" class="form-label">Tipo de Pago*</label><select id="tipo_pago" name="tipo_pago" class="form-control" required><option value="parcial">Pago parcial (abono)</option><option value="completo">Pago completo</option></select></div>
            <div><label for="metodo_pago_id" class="form-label">Método de Pago*</label><select name="metodo_pago_id" id="metodo_pago_id" class="form-control"></select></div>
            <div id="abono-container" class="md:col-span-2"><label for="monto_abono" class="form-label">Valor a abonar</label><input name="monto_abono" id="monto_abono" type="number" min="0" step="1000" class="form-control" placeholder="0" /></div>
            <div id="total-pago-completo" class="md:col-span-2" style="display:none;"><div class="text-center py-4"><span class="text-2xl font-bold text-green-600">Total a pagar: <span id="valor-total-pago">$0</span></span></div></div>
            <div class="md:col-span-2"><label for="notas" class="form-label">Notas Adicionales</label><textarea name="notas" id="notas" class="form-control" maxlength="500" rows="2" placeholder="Ej: Llegada tardía..."></textarea></div>
          </div>
        </fieldset>
        <div class="flex flex-col sm:flex-row gap-3 pt-2">
          <button type="submit" id="submit-button" class="button button-primary w-full sm:w-auto flex-grow">Registrar Reserva</button>
          <button type="button" id="cancel-edit-button" class="button button-secondary w-full sm:w-auto" style="display:none;">Cancelar Edición</button>
        </div>
      </form>
      <div id="reserva-feedback" class="mb-6 min-h-[24px]"></div>
      <div id="reservas-list" class="mt-8"></div>
    </div>
  `;

  ui.init(container); 
  
  const tipoPagoSelectEl = document.getElementById('tipo_pago');
  const abonoContainerEl = document.getElementById('abono-container');
  const montoAbonoInputEl = document.getElementById('monto_abono');
  const totalPagoCompletoEl = document.getElementById('total-pago-completo');
  const metodoPagoSelectEl = document.getElementById('metodo_pago_id');

  function actualizarVisibilidadPago() {
    const totalReserva = state.currentBookingTotal; 
    if (tipoPagoSelectEl.value === 'completo') {
      if (abonoContainerEl) abonoContainerEl.style.display = 'none';
      if (montoAbonoInputEl) { montoAbonoInputEl.value = ''; montoAbonoInputEl.required = false; }
      if (totalPagoCompletoEl) totalPagoCompletoEl.style.display = 'block';
      if (metodoPagoSelectEl) metodoPagoSelectEl.required = totalReserva > 0;
    } else { 
      if (abonoContainerEl) abonoContainerEl.style.display = 'block';
      if (montoAbonoInputEl) montoAbonoInputEl.required = (parseFloat(montoAbonoInputEl?.value) || 0) > 0;
      if (totalPagoCompletoEl) totalPagoCompletoEl.style.display = 'none';
      if (metodoPagoSelectEl) metodoPagoSelectEl.required = (parseFloat(montoAbonoInputEl?.value) || 0) > 0;
    }
  }
  
  if (tipoPagoSelectEl) tipoPagoSelectEl.addEventListener('change', actualizarVisibilidadPago);
  if (montoAbonoInputEl) {
      montoAbonoInputEl.addEventListener('input', () => {
          if (tipoPagoSelectEl.value === 'parcial' && metodoPagoSelectEl) {
              metodoPagoSelectEl.required = (parseFloat(montoAbonoInputEl.value) || 0) > 0;
          }
          actualizarVisibilidadPago(); 
      });
  }
  
  const inputsQueAfectanTotal = [
    ui.habitacionIdSelect, ui.cantidadNochesInput, ui.tipoCalculoDuracionEl, 
    ui.tiempoEstanciaIdSelect, ui.form.elements.cantidad_huespedes, ui.fechaEntradaInput
  ];

  inputsQueAfectanTotal.forEach(el => {
      if (el) {
        const eventType = (el.type === 'datetime-local' || el.type === 'number' || el.tagName === 'TEXTAREA') ? 'input' : 'change';
        const listener = async () => { 
            await recalcularYActualizarTotalUI();
            actualizarVisibilidadPago(); 
        };
        el.addEventListener(eventType, listener);
      }
  });

  if (ui.form) {
      // Asegurarse que handleFormSubmit está en el scope
      if (typeof handleFormSubmit === 'function') {
          ui.form.addEventListener('submit', handleFormSubmit);
      } else {
          console.error("CRITICAL: handleFormSubmit no está definido al intentar adjuntar listener.");
      }
  }
  if (ui.cancelEditButton) ui.cancelEditButton.onclick = () => resetFormToCreateMode();
  if (ui.reservasListEl) {
      // Asegurarse que handleListActions está en el scope
      if (typeof handleListActions === 'function') {
          ui.reservasListEl.addEventListener('click', handleListActions);
      } else {
          console.error("CRITICAL: handleListActions no está definido al intentar adjuntar listener.");
      }
  }

  if (ui.tipoCalculoDuracionEl) {
    ui.tipoCalculoDuracionEl.onchange = async () => { 
        const esNochesManual = ui.tipoCalculoDuracionEl.value === 'noches_manual';
        if(ui.nochesManualContainer) ui.nochesManualContainer.style.display = esNochesManual ? '' : 'none';
        if(ui.cantidadNochesInput) ui.cantidadNochesInput.required = esNochesManual;
        if(ui.tiempoPredefinidoContainer) ui.tiempoPredefinidoContainer.style.display = esNochesManual ? 'none' : '';
        if(ui.tiempoEstanciaIdSelect) ui.tiempoEstanciaIdSelect.required = !esNochesManual;
        await recalcularYActualizarTotalUI();
        actualizarVisibilidadPago();
    };
  }
  
  if (ui.fechaEntradaInput) configureFechaEntrada(ui.fechaEntradaInput);
  
  await loadInitialData(); 
  
  if (ui.tipoCalculoDuracionEl) {
      ui.tipoCalculoDuracionEl.dispatchEvent(new Event('change'));
  } else {
      await recalcularYActualizarTotalUI(); 
      actualizarVisibilidadPago();
  }
}

// --- UNMOUNT ---
export function unmount() {
    console.log("Reservas module unmounted.");
    state.isEditMode = false;
    state.editingReservaId = null;
    state.tiemposEstanciaDisponibles = [];
    state.currentBookingTotal = 0;
    state.configHotel = { 
        cobro_al_checkin: true, checkin_hora_config: "15:00", checkout_hora_config: "12:00",
        impuestos_incluidos_en_precios: false, porcentaje_impuesto_principal: 0, nombre_impuesto_aplicado: null,
    };
    // Si se usó addEventListener, se deberían remover aquí si el contenedor principal no se limpia con innerHTML=''
    // Por ejemplo:
    // if (ui.form && typeof handleFormSubmit === 'function') ui.form.removeEventListener('submit', handleFormSubmit);
    // if (ui.reservasListEl && typeof handleListActions === 'function') ui.reservasListEl.removeEventListener('click', handleListActions);
    // ... y para los otros addEventListener
}
// Fix for reservas.js: add missing functions to eliminate CRITICAL errors

// --- AGREGADOS FALTANTES AL FINAL ---

async function handleFormSubmit(event) {
  event.preventDefault();
  if (!ui.form || !ui.feedbackDiv) return;
  clearFeedback(ui.feedbackDiv);

  try {
    setFormLoadingState(ui.form, true);
    const formData = gatherFormData();
    validateInitialInputs(formData);
    const bookingPayload = await validateAndCalculateBooking(formData);
    const reservaData = state.isEditMode
      ? await updateBooking(bookingPayload)
      : await createBooking(bookingPayload);

    showSuccess(ui.feedbackDiv, state.isEditMode ? "Reserva actualizada." : "Reserva creada exitosamente.");
    resetFormToCreateMode();
    await renderReservas();
    document.dispatchEvent(new CustomEvent('datosActualizados'));
  } catch (err) {
    showError(ui.feedbackDiv, err.message);
  } finally {
    setFormLoadingState(ui.form, false);
  }
}

async function handleListActions(event) {
  const btn = event.target.closest('button[data-action]');
  if (!btn) return;
  const action = btn.getAttribute('data-action');
  const reservaId = btn.getAttribute('data-id');
  const habitacionId = btn.getAttribute('data-habitacion-id') || null;

  try {
    switch (action) {
      case 'editar':
        await prepareEditReserva(reservaId);
        break;
      case 'cancelar':
        await handleUpdateEstadoReserva(reservaId, 'cancelada', 'libre', habitacionId);
        break;
      case 'confirmar':
        await handleUpdateEstadoReserva(reservaId, 'confirmada', 'reservada', habitacionId);
        break;
      case 'checkin':
        const puedeCheckin = await puedeHacerCheckIn(reservaId);
        if (!puedeCheckin) {
          showError(ui.feedbackDiv, "Debe registrar el pago completo para poder hacer check-in.");
          return;
        }
        await handleUpdateEstadoReserva(reservaId, 'activa', 'ocupada', habitacionId);
        break;
      case 'checkout':
        await handleUpdateEstadoReserva(reservaId, 'completada', 'libre', habitacionId);
        break;
      case 'abonar':
        const { data: reservaActual, error: errRA } = await state.supabase
          .from('reservas')
          .select('*')
          .eq('id', reservaId)
          .single();
        if (errRA || !reservaActual) throw new Error("Reserva no encontrada.");
        await mostrarModalAbonoReserva(reservaActual);
        break;
      default:
        console.warn("Acción no reconocida:", action);
    }
  } catch (err) {
    if (ui.feedbackDiv) showError(ui.feedbackDiv, err.message);
  }
}

// EOF
